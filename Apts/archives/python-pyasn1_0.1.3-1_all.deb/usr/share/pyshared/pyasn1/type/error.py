from pyasn1.error import PyAsn1Error

class ValueConstraintError(PyAsn1Error): pass

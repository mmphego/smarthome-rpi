try:
    from path import *
except ImportError:
    from _path import *

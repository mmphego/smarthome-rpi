# This is an auto-generated file. Do not edit it.
from twisted.python import versions
version = versions.Version('twisted.web', 12, 0, 0)

#! /usr/bin/python
# -*- test-case-name: twisted.trial.test.test_test_visitor,twisted.trial.test.test_class -*-

# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

# fodder for test_script, which parses files for emacs local variable
# declarations.  This one is supposed to have:
#    test-case-name: twisted.trial.test.test_test_visitor
# in the second line
# The class declaration is irrelevant

class Foo(object):
    pass

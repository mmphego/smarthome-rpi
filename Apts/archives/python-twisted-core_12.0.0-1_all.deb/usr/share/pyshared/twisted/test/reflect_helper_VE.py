
# Helper for a test_reflect test

raise ValueError("Stuff is broken and things")
